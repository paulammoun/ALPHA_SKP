function _instantUpdateSettings() {
return {
	"baseLineGUID": "e10e619db9d744e18ab2a56f7b3bd1c2",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": ""
};
}